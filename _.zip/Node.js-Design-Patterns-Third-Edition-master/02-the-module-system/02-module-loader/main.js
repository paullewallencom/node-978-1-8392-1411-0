const moduleA = require('./moduleA')
moduleA.run()
