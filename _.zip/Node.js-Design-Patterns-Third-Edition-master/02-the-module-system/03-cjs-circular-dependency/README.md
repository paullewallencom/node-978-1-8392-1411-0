# 03-cjs-circular-dependency

This sample demonstrates what happens when there are cycles in module
dependencies using CommonJS.

## Run

```bash
node main
```