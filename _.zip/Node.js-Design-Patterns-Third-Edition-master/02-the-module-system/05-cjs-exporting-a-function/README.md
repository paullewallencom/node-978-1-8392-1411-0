# 05-cjs-exporting-a-function

This sample demonstrates how to export a function with CommonJS

## Run

```bash
node main
```