# 06-cjs-exporting-a-constructor

This sample demonstrates how to export a constructor with CommonJS

## Run

```bash
node main
```