// import a single member of the module
import { log } from './logger.js'

log('Hello World')
