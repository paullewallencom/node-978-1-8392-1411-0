import MyLogger from './logger.js'

const logger = new MyLogger('info')
logger.log('Hello World')
