# 11-esm-async-imports

This sample demonstrates how to load modules dynamically with ESM

## Run

```bash
node main.js el
node main.js en
node main.js es
node main.js it
node main.js pl
node main.js pt # <- this one will fail
```