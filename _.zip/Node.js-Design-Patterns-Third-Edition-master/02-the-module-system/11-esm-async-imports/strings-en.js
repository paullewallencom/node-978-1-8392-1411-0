export const HELLO = 'Hello World'
