export const HELLO = 'Hola mundo'
