export const HELLO = 'Witaj świecie'
