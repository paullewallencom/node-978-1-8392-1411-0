# 12-esm-mixed-exports

This sample demonstrates a mixed syntax with named and default import/export

## Run

```bash
node main.js
```