# 14-esm-read-only-live-bindings

This sample demonstrates that imported ESM modules are read-only live bindings

## Run

```bash
node main.js
node main.cjs
```