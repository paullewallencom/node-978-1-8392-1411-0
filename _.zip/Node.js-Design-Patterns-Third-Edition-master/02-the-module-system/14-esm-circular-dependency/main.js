import * as a from './a.js'
import * as b from './b.js'

console.log('a ->', a)
console.log('b ->', b)
