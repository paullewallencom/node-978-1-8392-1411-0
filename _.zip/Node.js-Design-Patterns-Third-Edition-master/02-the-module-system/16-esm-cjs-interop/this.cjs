console.log(this === exports) // true
