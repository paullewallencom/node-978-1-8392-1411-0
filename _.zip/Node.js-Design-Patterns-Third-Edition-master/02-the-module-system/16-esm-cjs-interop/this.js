console.log(this) // undefined
