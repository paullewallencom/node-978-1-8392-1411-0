# 01-sync-cps

This example demonstrates continuous passing with callbacks.

## Run

To run the example launch:

```bash
node index
```
