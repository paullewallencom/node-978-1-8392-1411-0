# 03-non-cps

This example demonstrates how callbacks are not always used to implement continuous-passing style.

## Run

To run the example launch:

```bash
node index
```
