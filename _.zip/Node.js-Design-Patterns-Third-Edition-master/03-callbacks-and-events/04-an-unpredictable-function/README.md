# 04-an-unpredictable-function

This example demonstrates how a function can behave synchronously under certain circumstances and asynchronously under other.

## Run

To run the example launch:

```bash
node index.js
```
