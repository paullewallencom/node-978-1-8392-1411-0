# 05-fix-zalgo-with-sync-api

This example demonstrates how to fix Zalgo by making our unpredictable function synchronous.

## Run

To run the example launch:

```bash
node index.js
```
