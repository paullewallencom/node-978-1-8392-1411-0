# 07-propagating-errors

This example demonstrates how to propagate errors in asynchronous CPS APIs.

## Run

To run the example launch:

```bash
node index.js
```
