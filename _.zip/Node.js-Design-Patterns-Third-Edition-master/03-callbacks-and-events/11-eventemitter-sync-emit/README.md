# 11-eventemitter-sync-emit

This sample demonstrates how to handle events when they are produced synchronously.

## Run

To run the example launch:

```bash
node index.js
