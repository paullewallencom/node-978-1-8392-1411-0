# 01-web-spider

First version of web spider that demonstrates CPS and callback hell.

## Run

Install the necessary dependencies with `npm install` and then run:

```bash
node spider-cli.js https://loige.co
```
