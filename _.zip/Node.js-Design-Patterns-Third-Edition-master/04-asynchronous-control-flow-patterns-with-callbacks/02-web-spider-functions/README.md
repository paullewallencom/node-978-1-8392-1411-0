# 02-web-spider-functions

Refactored version of web spider that cleans up callback hell.

## Run

Install the necessary dependencies with `npm install` and then run:

```bash
node spider-cli.js https://loige.co
```
