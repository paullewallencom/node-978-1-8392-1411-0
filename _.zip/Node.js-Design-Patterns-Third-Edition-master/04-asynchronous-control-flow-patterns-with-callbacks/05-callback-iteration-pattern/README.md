# 05-callback-iterator-pattern

Simple example that demonstrates the callback iteration pattern

## Run

Run:

```bash
node test.js
```
