# 07-callback-unlimited-parallel-execution-pattern

Simple example that demonstrates the callback parallel execution pattern

## Run

Run:

```bash
node test.js
```
