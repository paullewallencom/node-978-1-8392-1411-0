# 08-callback-limited-parallel-execution-pattern

Simple example that demonstrates the callback limited parallel execution pattern

## Run

Run:

```bash
node test.js
```
