# 01-delay-with-promises

This sample demonstrates how to use the `Promise` constructor to create a new `Promise` from scratch.

## Run

To run the example launch:

```bash
node index.js
```
