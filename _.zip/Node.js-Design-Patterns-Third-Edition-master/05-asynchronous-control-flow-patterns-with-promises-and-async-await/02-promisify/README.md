# 02-promisify

This sample demonstrates how to *promisify* a Node.js-style callback-based function.

## Run

To run the example launch:

```bash
node index.js
```
