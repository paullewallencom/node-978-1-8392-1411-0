# 08-asyncawait-return-await-trap

This sample demonstrates how `return promise` is different than `return await promise` when it comes to error handling.

## Run

To run the example launch:

```bash
node errorNotCaught.js
node errorCaught.js
```
