# 07-custom-readable

This examples shows how to implement a custom Readable stream.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example you can run:

```bash
node index.js
```

or:

```bash
node simplified-construction.js
```
