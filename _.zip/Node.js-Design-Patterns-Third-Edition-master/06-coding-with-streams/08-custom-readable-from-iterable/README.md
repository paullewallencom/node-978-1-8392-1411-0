# 08-custom-readable-from-iterable

This examples shows how to implement a custom Readable stream using `Readable.from`.


## Run

To run the example you can run:

```bash
node index.js
```
