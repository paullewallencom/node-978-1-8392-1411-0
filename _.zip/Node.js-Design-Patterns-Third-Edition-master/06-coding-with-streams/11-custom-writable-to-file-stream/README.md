# 11-custom-writable-to-file-stream

This examples shows how to create a custom writable stream.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node index.js
```

or

```bash
node simplified-construction.js
```
