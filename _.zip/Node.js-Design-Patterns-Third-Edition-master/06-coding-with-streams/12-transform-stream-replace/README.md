# 12-transform-stream-replace

This examples shows how to create a custom transform stream.


## Run

To run the example:

```bash
node index.js
```

or

```bash
node simplified-construction.js
```

