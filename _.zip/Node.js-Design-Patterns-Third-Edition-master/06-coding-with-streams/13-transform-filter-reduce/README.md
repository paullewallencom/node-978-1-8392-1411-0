# 13-transform-filter-reduce

This examples shows how to use Transform streams to implement streaming data filter and reduce blocks.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node index.js
```
