# 14-passthrough-monitoring

This examples shows how to create and use a PassThrough stream.


## Run

To run the example:

```bash
node index.js
```
