# 16-connecting-streams-using-pipes

This examples shows how to connect streams using `.pipe()`.


## Run

To run the example:

```bash
echo Hello World! | node replace.js World Node.js
```
