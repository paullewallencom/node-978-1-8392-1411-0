# 25-multiplexing

This examples shows how to perform multiplexing and demultiplexing using Node.js streams.


## Run

To run the example you need to start a server in a terminal window with:

```bash
node server.js
```

Then you can start a client:

```bash
node client.js generate-data.js
```
