# 01-factory-simple

This example shows how to implement a simple factory function.

## Run

To run the example launch:

```bash
node index.js
```

