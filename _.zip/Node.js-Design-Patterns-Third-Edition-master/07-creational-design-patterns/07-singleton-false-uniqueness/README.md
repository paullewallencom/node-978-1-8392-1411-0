# 07-singleton-false-uniqueness

This example demonstrate how under certain conditions, an instance exported by a module stops to be a Singleton.

## Run

To run the example launch:

```bash
node index.js
```

NOTE: Don't run `npm install` or the since this sample is composed of some fake dependencies which otherwise would be overwritten.
