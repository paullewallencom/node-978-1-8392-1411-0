# 09-dependency-injection

This example shows how to wire dependencies using the dependency injection pattern

## Dependencies

Install all necessary dependencies with:

```shell script
npm install
```

## Run

To run the example:

```shell script
node import-posts.js
node index.js
```
