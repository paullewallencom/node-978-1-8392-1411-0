# 01-proxy-composition

This example demonstrate how to create a proxy object using composition

## Run

To run the example launch:

```bash
node index.js
```
