# 02-proxy-object-literal

This example demonstrate how to create a proxy object using object literals

## Run

To run the example launch:

```bash
node index.js
```
