# 03-proxy-object-augmentation

This example demonstrate how to create a proxy object using object augmentation (Monkey patching)

## Run

To run the example launch:

```bash
node index.js
```
