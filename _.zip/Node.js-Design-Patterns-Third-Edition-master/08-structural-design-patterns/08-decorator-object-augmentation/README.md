# 08-decorator-object-augmentation

This example demonstrate how to implement the decorator pattern using object augmentation

## Run

To run the example launch:

```bash
node index.js
```
