# 09-decorator-es2015

This example demonstrate how to implement the decorator pattern using ES2015 proxy

## Run

To run the example launch:

```bash
node index.js
```
