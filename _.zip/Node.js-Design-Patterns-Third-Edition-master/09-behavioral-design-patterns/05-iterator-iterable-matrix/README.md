# 05-iterator-iterable-matrix

This sample demonstrates how to implement the Iterable protocol.

## Run

To run the example launch:

```
node index.js
```

