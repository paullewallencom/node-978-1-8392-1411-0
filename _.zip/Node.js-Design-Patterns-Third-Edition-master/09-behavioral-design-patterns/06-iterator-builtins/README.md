# 06-iterator-builtins

This sample demonstrates the different constructs and built-in APIs supporting iterables.

## Run

To run the example launch:

```
node index.js
```

