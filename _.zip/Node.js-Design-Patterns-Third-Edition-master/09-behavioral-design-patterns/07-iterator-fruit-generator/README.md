# 07-iterator-fruit-generator

This sample demonstrates how to create a simple generator function.

## Run

To run the example launch:

```
node index.js
```

