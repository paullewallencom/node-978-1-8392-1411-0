# 10-async-iterator-check-urls

This sample demonstrates how to use a generator in place of a standard iterator.

## Run

To run the example install its dependencies with `npm install`, then launch:

```
node index.js
```

