# 14-command

This sample demonstrates a simple implementation of the Command pattern.

## Run

To run the example install its dependencies with `npm install`, then run the following commands in two different terminals:

```
node server.js
```

And then:

```
node client.js
```
