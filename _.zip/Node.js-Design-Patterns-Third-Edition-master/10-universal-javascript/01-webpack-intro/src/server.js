import { sayHello } from './say-hello.js'

console.log(sayHello('Node.js'))
